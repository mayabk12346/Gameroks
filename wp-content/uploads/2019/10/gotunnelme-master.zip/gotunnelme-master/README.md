gotunnelme
==========

golang version of http://localtunnel.me client


Run either as commandline program:

```
gotunnelme <local port>
```

Or you can use the library at `src/gotunnelme/`
